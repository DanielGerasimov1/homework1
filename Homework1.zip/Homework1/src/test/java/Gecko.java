import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Gecko {

    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.gecko.driver", "C:\\\\Users\\\\dangr\\\\OneDrive\\\\Desktop\\\\geckodriver\\\\geckodriver-v0.34.0-win64\\\\geckodriver.exe\\");

        WebDriver driver = new FirefoxDriver();
        driver.get("https://www.google.com/");

        Thread.sleep(3000);
        WebElement searchField = driver.findElement(By.name("q"));
        searchField.sendKeys(new CharSequence[]{"QA"});

        Thread.sleep(3000);

        searchField.submit();

        Thread.sleep(3000);

        driver.quit();

    }
}
