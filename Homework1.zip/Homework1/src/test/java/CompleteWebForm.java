import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CompleteWebForm {

    public static void main(String[] args) throws InterruptedException {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\dangr\\OneDrive\\Desktop\\Eugeny installs\\Chromedriver\\chromedriver-win32\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        driver.get("https://formy-project.herokuapp.com/form");
        driver.manage().window().maximize();

        WebElement firstName = driver.findElement(By.id("first-name"));
        firstName.sendKeys("Daniel");
        firstName.sendKeys(Keys.RETURN);
        Thread.sleep(2000);

        WebElement lastName = driver.findElement(By.id("last-name"));
        lastName.sendKeys("Gerasimov");
        lastName.sendKeys(Keys.RETURN);
        Thread.sleep(2000);

        WebElement jobTitle = driver.findElement(By.id("job-title"));
        jobTitle.sendKeys("Store-Manager");
        jobTitle.sendKeys(Keys.RETURN);
        Thread.sleep(2000);

        WebElement highSchoolButton = driver.findElement(By.id("radio-button-1"));
        highSchoolButton.click();
        Thread.sleep(2000);

        WebElement collegeButton = driver.findElement(By.id("radio-button-2"));
        collegeButton.click();
        Thread.sleep(2000);

        WebElement gradSchoolButton = driver.findElement(By.id("radio-button-3"));
        gradSchoolButton.click();
        Thread.sleep(2000);

        WebElement maleGender = driver.findElement(By.id("checkbox-1"));
        maleGender.click();
        Thread.sleep(2000);

        WebElement femaleGender = driver.findElement(By.id("checkbox-2"));
        femaleGender.click();
        Thread.sleep(2000);

        WebElement naGender = driver.findElement(By.id("checkbox-3"));
        naGender.click();
        Thread.sleep(2000);

        WebElement dropDown= driver.findElement(By.id("select-menu"));
                   Select selectOne = new Select(dropDown);
                   selectOne.selectByIndex(1);
        Thread.sleep(2000);
                   selectOne.selectByIndex(2);
        Thread.sleep(2000);
                   selectOne.selectByIndex(3);
        Thread.sleep(2000);
                   selectOne.selectByIndex(4);
        Thread.sleep(2000);

        WebElement datePicker = driver.findElement(By.id("datepicker"));
        datePicker.sendKeys("07/19/2024");
        datePicker.sendKeys(Keys.RETURN);
        Thread.sleep(3000);

        driver.quit();
    }
}