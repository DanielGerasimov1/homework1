import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Wiki {

    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\dangr\\OneDrive\\Desktop\\Eugeny installs\\Chromedriver\\chromedriver-win32\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.get("https://www.wiki.com/");

        Thread.sleep(3000);

        WebElement searchField = driver.findElement(By.name("q"));
        searchField.sendKeys(new CharSequence[]{"QA"});

        Thread.sleep(3000);

        searchField.submit();

        Thread.sleep(3000);

        driver.quit();
    }
}
